// auth_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/auth_provider.dart';
import 'home_screen.dart';

class AuthScreen extends StatefulWidget {
  static const routeName = '/auth';
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> with TickerProviderStateMixin {
  late final TabController _tabController = TabController(
    length: 2,
    vsync: this,
  );
  late final AnimationController _bgController;

  final _loginEmail = TextEditingController();
  final _loginPassword = TextEditingController();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();

  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _bgController.dispose();
    _loginEmail.dispose();
    _loginPassword.dispose();
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _doLogin() async {
    setState(() => _loading = true);
    try {
      await context.read<AuthProvider>().login(
        _loginEmail.text.trim(),
        _loginPassword.text.trim(),
      );
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, HomeScreen.routeName);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Login failed: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _doSignup() async {
    setState(() => _loading = true);
    try {
      await context.read<AuthProvider>().signup(
        _name.text.trim(),
        _email.text.trim(),
        _password.text.trim(),
      );
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, HomeScreen.routeName);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Signup failed: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  LinearGradient _animatedGradient(double t) {
    final g1 = [Colors.indigo.shade800, Colors.purple.shade600];
    final g2 = [Colors.teal.shade700, Colors.blue.shade400];
    final c0 = Color.lerp(g1[0], g2[0], t)!;
    final c1 = Color.lerp(g1[1], g2[1], t)!;
    return LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [c0, c1],
    );
  }

  @override
  Widget build(BuildContext context) {
    final safeTop = MediaQuery.of(context).padding.top;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Welcome',
          style: GoogleFonts.lato(fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: AnimatedBuilder(
        animation: _bgController,
        builder: (context, child) {
          final t = Curves.easeInOut.transform(_bgController.value);
          return Container(
            decoration: BoxDecoration(gradient: _animatedGradient(t)),
            child: child,
          );
        },
        child: SafeArea(
          minimum: EdgeInsets.only(top: safeTop + 8),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.12)),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    color: Colors.white.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  labelStyle: GoogleFonts.lato(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  unselectedLabelStyle: GoogleFonts.lato(fontSize: 15),
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white70,
                  tabs: const [
                    Tab(text: 'Login'),
                    Tab(text: 'Sign up'),
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _AnimatedFormWrapper(
                      key: const ValueKey('login'),
                      loading: _loading,
                      onSubmit: _doLogin,
                      children: [
                        _buildTextField(
                          controller: _loginEmail,
                          label: 'Email',
                          keyboardType: TextInputType.emailAddress,
                        ),
                        _buildTextField(
                          controller: _loginPassword,
                          label: 'Password',
                          obscureText: true,
                        ),
                      ],
                    ),
                    _AnimatedFormWrapper(
                      key: const ValueKey('signup'),
                      loading: _loading,
                      onSubmit: _doSignup,
                      children: [
                        _buildTextField(controller: _name, label: 'Name'),
                        _buildTextField(
                          controller: _email,
                          label: 'Email',
                          keyboardType: TextInputType.emailAddress,
                        ),
                        _buildTextField(
                          controller: _password,
                          label: 'Password',
                          obscureText: true,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    bool obscureText = false,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      style: GoogleFonts.lato(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.lato(color: Colors.white70),
        filled: true,
        fillColor: Colors.black.withOpacity(0.12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          vertical: 14,
          horizontal: 12,
        ),
      ),
    );
  }
}

class _AnimatedFormWrapper extends StatefulWidget {
  final bool loading;
  final VoidCallback onSubmit;
  final List<Widget> children;
  const _AnimatedFormWrapper({
    super.key,
    required this.loading,
    required this.onSubmit,
    required this.children,
  });

  @override
  State<_AnimatedFormWrapper> createState() => _AnimatedFormWrapperState();
}

class _AnimatedFormWrapperState extends State<_AnimatedFormWrapper>
    with SingleTickerProviderStateMixin {
  late final AnimationController _entranceController;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant _AnimatedFormWrapper oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.key != widget.key) {
      _entranceController.forward(from: 0.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final slide = Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero)
        .animate(
          CurvedAnimation(parent: _entranceController, curve: Curves.easeOut),
        );
    final fade = CurvedAnimation(
      parent: _entranceController,
      curve: Curves.easeIn,
    );

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: SlideTransition(
        position: slide,
        child: FadeTransition(
          opacity: fade,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ...widget.children
                  .map(
                    (w) => Padding(
                      padding: const EdgeInsets.only(bottom: 12.0),
                      child: w,
                    ),
                  )
                  .toList(),
              const SizedBox(height: 8),
              PressableButton(
                loading: widget.loading,
                onPressed: widget.onSubmit,
                child: Text(
                  widget.loading ? 'Please wait' : 'Continue',
                  style: GoogleFonts.lato(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PressableButton extends StatefulWidget {
  final bool loading;
  final VoidCallback onPressed;
  final Widget child;
  const PressableButton({
    super.key,
    required this.loading,
    required this.onPressed,
    required this.child,
  });

  @override
  State<PressableButton> createState() => _PressableButtonState();
}

class _PressableButtonState extends State<PressableButton>
    with SingleTickerProviderStateMixin {
  double _scale = 1.0;

  void _onTapDown(TapDownDetails _) => setState(() => _scale = 0.96);
  void _onTapUp(TapUpDetails _) => setState(() => _scale = 1.0);
  void _onTapCancel() => setState(() => _scale = 1.0);

  @override
  Widget build(BuildContext context) {
    final isDisabled = widget.loading;
    return AnimatedScale(
      scale: _scale,
      duration: const Duration(milliseconds: 120),
      curve: Curves.easeOutCubic,
      child: GestureDetector(
        onTapDown: isDisabled ? null : _onTapDown,
        onTapUp: isDisabled
            ? null
            : (d) {
                _onTapUp(d);
                widget.onPressed();
              },
        onTapCancel: isDisabled ? null : _onTapCancel,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isDisabled
                  ? [
                      Colors.white.withOpacity(0.12),
                      Colors.white.withOpacity(0.08),
                    ]
                  : [
                      Colors.white.withOpacity(0.18),
                      Colors.white.withOpacity(0.10),
                    ],
            ),
            borderRadius: BorderRadius.circular(10),
            boxShadow: isDisabled
                ? []
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.25),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.04),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                  ],
          ),
          child: Center(
            child: widget.loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                : widget.child,
          ),
        ),
      ),
    );
  }
}
